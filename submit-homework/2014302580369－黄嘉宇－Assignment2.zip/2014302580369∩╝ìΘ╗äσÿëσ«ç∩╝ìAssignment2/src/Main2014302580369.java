import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580369 {

	public static void main(String[] args) throws IOException {
		File in = new File("ifor.html"); //导入html文件
		Document doc = Jsoup.parse(in,"UTF-8","http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha%20Quan%20Xing"); 
		Elements name = doc.select("h3[class]:matches([\u4e00-\u9fa5]{3})");//通过正则获取教师的名字
		String mingzi = name.text();
		Elements phonenumber = doc.select("p:matchesOwn(0\\d{2}-\\d{8})");//获得电话那栏的所有信息（此处不知道如何单独获得该信息）
		String number = phonenumber.text();		
		FileOutputStream out = new FileOutputStream("ifor.txt");//输出文件		
		out.write("姓名：".getBytes());
		out.write(mingzi.getBytes());
		out.write("\n".getBytes());
		out.write("简介：".getBytes());//写入信息
		String[] information = number.split(" ");
		for(int i=0; i<information.length; i++)
		{
			out.write(information[i].getBytes());
			if( i>1&i%2==0)
			{
				out.write("\n".getBytes());
			}
		}//通过群里了解该方法，将各个信息拆分
		
		out.close();
		System.out.println("get ifor.txt");
        	
}
}