import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;

public class GetIfor {
	public static void main(String args[]){            //method
		   
		   String url ="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha%20Quan%20Xing";//string url
		   String gname = "ifor"+".html";             //file name
		 	   HttpRequest response = HttpRequest.get(url);			 	   	//get url		 	  
		    			   response.receive(new File(gname));		 //receive File   				    			    	
		    	System.out.printf("get");		   
	   }
}
